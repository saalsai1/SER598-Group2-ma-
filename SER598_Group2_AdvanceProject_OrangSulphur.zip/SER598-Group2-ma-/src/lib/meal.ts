export const MEALDB_BASE='https://www.themealdb.com/api/json/v1/1'
export const MEALDB_KEY="1"